using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{
    public Button Start;
public void NextScene()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentSceneIndex + 1);
    }
    public void OnClickSceneChange()
    {
        int Sceneindex = SceneManager.GetActiveScene().buildIndex;
        if (Sceneindex != SceneManager.sceneCount)
        {
            SceneManager.LoadScene( + 1);
        }
    }
    public void QuitGame()
    {
        Application.Quit();
    }
}

